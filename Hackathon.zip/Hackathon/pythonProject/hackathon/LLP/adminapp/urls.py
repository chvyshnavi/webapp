from django.urls import path
from . import views

urlpatterns = [
    path('', views.projecthomepage, name='projecthomepage'),
    path('login/', views.loginpage, name='loginpage'),
    path('register/', views.Registerpage, name='registerpage'),
    path('UserLoginLogic/', views.UserLoginLogic, name='UserLoginLogic'),
    path('UserRegisterLogic/', views.UserRegisterLogic, name='UserRegisterLogic'),
    path('logout/', views.logout_view, name='logout'),
    path('add_student/', views.add_student, name='add_student'),
    path('add_studentpagecall/', views.add_studentpagecall, name='add_studentpagecall'),
    path('student_list/', views.student_list, name='student_list'),
]