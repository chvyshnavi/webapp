from django.urls import path,include
from . import views

app_name = 'instructorapp'

urlpatterns = [
 path('instructorapp/',views.instructorhomepagecall,name='instructorhomepagecall')

]
