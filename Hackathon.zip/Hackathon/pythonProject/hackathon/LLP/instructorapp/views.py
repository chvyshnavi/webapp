from django.shortcuts import render

def instructorhomepagecall(request):
    return render(request, 'instructorapp/instructorhomepage.html')