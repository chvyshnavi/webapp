from django.urls import path,include
from . import views
app_name = 'studentapp'

urlpatterns = [
path('studenthomepagecall/', views.studenthomepagecall, name='studenthomepagecall'),
    path('Frenchpagecall/',views.Frenchpagecall,name='Frenchpagecall'),


    path('germanpagecall/',views.germanpagecall,name='germanpagecall'),

    path('spanishpagecall/', views.spanishpagecall, name='spanishpagecall'),

    path('dutchpagecall/', views.dutchpagecall, name='dutchpagecall'),



    path('portuguesepagecall/', views.portuguesepagecall, name='portuguesepagecall'),

    path('italianpagecall/', views.italianpagecall, name='italianpagecall'),
    path('german1/', views.german, name='german1'),

    path('dutch1/', views.dutch1, name='dutch1'),

    path('french1/', views.French1pagecall, name='french1'),

    path('spanish1/', views.spanish1pagecall, name='spanish1'),

    path('italian1/', views.italian1pagecall, name='italian1'),

    path('portuguese1/', views.portuguese1pagecall, name='portuguese1'),
    path('german1/', views.german1, name='german1'),










]

