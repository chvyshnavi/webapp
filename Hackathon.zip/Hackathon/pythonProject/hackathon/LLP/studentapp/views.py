from django.shortcuts import render

# Create your views here.
def studenthomepagecall(request):
    return render(request, 'studentapp/studenthomepage.html')

def germanpagecall(request):
    return render(request, 'studentapp/german.html')


def Frenchpagecall(request):
    return render(request, 'studentapp/French.html')

def spanishpagecall(request):
    return render(request,'studentapp/spanish.html')

def dutchpagecall(request):
    return render(request,'studentapp/dutch.html')
def portuguesepagecall(request):
    return render(request,'studentapp/portuguese.html')

def italianpagecall(request):
    return render(request,'studentapp/italian.html')

def german(request):
    return render(request, 'studentapp/german.html')

def dutch1(request):

        return render(request, 'studentapp/dutch1.html')

def French1pagecall(request):
    return render(request, 'studentapp/french1.html')

def spanish1pagecall(request):
    return render(request,'studentapp/spanish1.html')

def italian1pagecall(request):
    return render(request,'studentapp/italian1.html')
def portuguese1pagecall(request):
    return render(request,'studentapp/portuguese1.html')
def german1(request):
    return render(request, 'studentapp/german1.html')